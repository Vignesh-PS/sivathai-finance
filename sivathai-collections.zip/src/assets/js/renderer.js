console.log('loaded renderer');
const { remote } = require('electron');

const remoteApp = require('electron').remote;

const knex = require('knex')({
  client: 'sqlite3',
  connection: {
    filename: remoteApp.app.getPath('documents')+'\\'+remoteApp.app.getName()+'\\sivathai.db'
  },
});
