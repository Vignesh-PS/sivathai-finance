module.exports = {
    db_location: 'sivathai.db'
};
